<?php
$pdo = new PDO("mysql:host=localhost;dbname=resource_marketplace;charset=utf8mb4", "root", "");

$names = [
    'Kate Mendoza',
    'Eunice Anne Mendoza',
];

$placeholders = implode(',', array_fill(0, count($names), '?'));
$stmt = $pdo->prepare("SELECT id, CONCAT_WS(' ', first_name, middle_name, last_name) AS full_name, email FROM users WHERE CONCAT_WS(' ', first_name, middle_name, last_name) IN ($placeholders)");
$stmt->execute($names);
$users = $stmt->fetchAll();

if (!$users) {
    echo "NO_MATCHING_USERS\n";
    exit(0);
}

foreach ($users as $user) {
    echo "USER: {$user['full_name']} | {$user['email']} | id={$user['id']}\n";
    $listingStmt = $pdo->prepare("SELECT id, title, status, price FROM listings WHERE seller_id = ? ORDER BY id");
    $listingStmt->execute([$user['id']]);
    $listings = $listingStmt->fetchAll();
    if (!$listings) {
        echo "  NO_LISTINGS\n";
        continue;
    }
    foreach ($listings as $listing) {
        echo "  LISTING: id={$listing['id']} | title={$listing['title']} | status={$listing['status']} | price={$listing['price']}\n";
    }
}

$deleteUserIds = array_map(fn($u) => (int)$u['id'], $users);
if ($deleteUserIds) {
    $ids = implode(',', array_fill(0, count($deleteUserIds), '?'));
    // Delete listings owned by the matched sellers
    $listingsStmt = $pdo->prepare("DELETE FROM listings WHERE seller_id IN ($ids)");
    $listingsStmt->execute($deleteUserIds);
    echo "DELETED_LISTINGS=" . $listingsStmt->rowCount() . "\n";
}
